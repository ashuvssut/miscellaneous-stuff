# Customizing you Git Bash

Replace C:\Program Files\Git\etc\profile.d\git-prompt.sh with the custom git-prompt.sh (YOU WILL NEED ADMINISTRATOR PREVILEGES)